export const COLOR_PRIMARY = '#58C9B9';
export const COLOR_SECONDARY = '#111';